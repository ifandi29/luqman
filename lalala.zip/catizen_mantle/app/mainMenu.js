import a22_0x33a70d from "react";
import { render } from "ink";
import a22_0x44e1db from "./components/mainMenuComponent.js";
async function MainMenu(_0x361ba0) {
  return new Promise(_0x574749 => {
    let _0xd7cfcd;
    const {
      waitUntilExit: _0x2bcd90
    } = render(a22_0x33a70d.createElement(a22_0x44e1db, {
      banner: _0x361ba0,
      onChange: _0x12646e => {
        _0xd7cfcd = _0x12646e;
        _0x574749(_0xd7cfcd);
      }
    }));
    _0x2bcd90();
  });
}
export default MainMenu;
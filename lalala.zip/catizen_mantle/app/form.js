import { render } from "ink";
import a8_0x2a1a2e from "react";
import a8_0x27bc42 from "./components/formComponent.js";
async function Form(_0x47d84e, _0x46dd5c) {
  return new Promise(_0x1375a5 => {
    let _0x4d0c34;
    const {
      waitUntilExit: _0x2a3bcc
    } = render(a8_0x2a1a2e.createElement(a8_0x27bc42, {
      name: _0x47d84e,
      banner: _0x46dd5c,
      onChange: _0x73a8e0 => {
        _0x4d0c34 = _0x73a8e0;
        _0x1375a5(_0x4d0c34);
      }
    }));
    _0x2a3bcc();
  });
}
export default Form;
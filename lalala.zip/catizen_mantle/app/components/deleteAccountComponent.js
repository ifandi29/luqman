import a1_0x59e520 from "chalk";
import { Box, Text, useFocusManager, useInput } from "ink";
import a1_0x356c0c, { useEffect, useState } from "react";
import a1_0x16cc6f from "./itemMenuComponent.js";
import { deleteFile } from "../utils/helper.js";
const DeleteAccountComponent = ({
  accounts: _0x58af87,
  banner: _0x210f6f,
  onChange: _0x38c12d
}) => {
  const {
    focus: _0x2f5eff
  } = useFocusManager();
  const [_0x10655f, _0x42b64b] = useState(1);
  const [_0x52ff35, _0x3ab50e] = useState(null);
  const [_0x7de583, _0x55c2c8] = useState(false);
  const [_0x581404, _0xf72d91] = useState(null);
  useInput((_0x34504f, _0x326731) => {
    if (_0x34504f === "q" && !_0x7de583) {
      _0x38c12d("exit");
      return;
    }
    if (_0x34504f === "y" && _0x7de583) {
      _0x55c2c8(false);
      if (_0x52ff35 !== null) {
        const _0x297a0e = deleteFile(_0x58af87[_0x52ff35].location);
        if (_0x297a0e.status) {
          _0x42b64b(_0x52ff35);
          _0x58af87.splice(_0x52ff35, 1);
        }
        _0xf72d91(_0x297a0e.message);
      }
      if (_0x58af87.length < 1) {
        _0x38c12d("back");
        return;
      }
      return;
    }
    if (_0x34504f === "n" && _0x7de583) {
      _0x55c2c8(false);
      return;
    }
    if (_0x326731.upArrow && !_0x7de583) {
      _0x42b64b(_0x10655f - 1);
    }
    if (_0x326731.downArrow && !_0x7de583) {
      _0x42b64b(_0x10655f + 1);
    }
    if (_0x326731.return && !_0x7de583) {
      _0x3ab50e(_0x10655f - 1);
      _0x55c2c8(true);
      return;
    }
    if (_0x326731.escape) {
      _0x38c12d("back");
      return;
    }
  });
  useEffect(() => {
    _0xf72d91(null);
    if (_0x10655f > _0x58af87.length) {
      _0x42b64b(1);
      _0x2f5eff("1");
    } else if (_0x10655f < 1) {
      _0x42b64b(_0x58af87.length);
      _0x2f5eff(_0x58af87.length.toString());
    } else {
      _0x2f5eff(_0x10655f.toString());
    }
    if (_0x58af87.length < 1) {
      _0x38c12d("");
      return;
    }
  }, [_0x10655f]);
  return a1_0x356c0c.createElement(Box, {
    flexDirection: "column",
    width: 52
  }, a1_0x356c0c.createElement(Text, null), a1_0x356c0c.createElement(Box, {
    flexDirection: "column",
    marginRight: 2
  }, a1_0x356c0c.createElement(Box, {
    flexDirection: "column",
    marginLeft: 6
  }, a1_0x356c0c.createElement(Box, {
    marginBottom: 1
  }, a1_0x356c0c.createElement(Text, {
    color: "greenBright"
  }, "Delete Account")), _0x58af87.map((_0x516435, _0x3b1b8b) => a1_0x356c0c.createElement(a1_0x16cc6f, {
    key: _0x3b1b8b,
    id: (_0x3b1b8b + 1).toString(),
    label: _0x516435.name
  }))), _0x7de583 && a1_0x356c0c.createElement(Box, {
    marginTop: 1
  }, a1_0x356c0c.createElement(Text, {
    color: "whiteBright"
  }, a1_0x59e520.magenta("[") + a1_0x59e520.yellowBright("!") + a1_0x59e520.magenta("]"), " ", "Are you sure (y/n):")), _0x581404 && a1_0x356c0c.createElement(Box, {
    marginTop: 1
  }, a1_0x356c0c.createElement(Text, {
    color: "yellowBright"
  }, a1_0x59e520.magenta("[") + a1_0x59e520.yellowBright("!") + a1_0x59e520.magenta("]"), " ", _0x581404)), a1_0x356c0c.createElement(Box, {
    marginTop: 1
  }, a1_0x356c0c.createElement(Text, null, a1_0x59e520.magenta("[") + a1_0x59e520.white("CTRL") + a1_0x59e520.blackBright(" + ") + a1_0x59e520.white("C") + a1_0x59e520.magenta("]") + a1_0x59e520.blackBright(" or ") + a1_0x59e520.white("Q") + a1_0x59e520.blackBright(" for exit, ") + a1_0x59e520.white("ESC") + a1_0x59e520.blackBright(" for back")))));
};
export default DeleteAccountComponent;
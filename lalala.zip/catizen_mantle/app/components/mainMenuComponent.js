import a4_0x262d72 from "react";
import { Box, Text } from "ink";
import a4_0x1a8fca from "chalk";
import { useMainMenu } from "../hooks/useMainMenu.js";
import a4_0x4d5060 from "./itemMenuComponent.js";
const MainMenuComponent = ({
  banner: _0x4b01d2,
  onChange: _0x4bfe12
}) => {
  const {
    message: _0x55605b
  } = useMainMenu({
    onChange: _0x4bfe12
  });
  return a4_0x262d72.createElement(Box, {
    flexDirection: "column",
    width: 52
  }, a4_0x262d72.createElement(Text, null), a4_0x262d72.createElement(Box, {
    flexDirection: "column",
    marginRight: 2
  }, a4_0x262d72.createElement(Box, {
    flexDirection: "column",
    marginLeft: 6
  }, a4_0x262d72.createElement(Box, {
    marginBottom: 1
  }, a4_0x262d72.createElement(Text, {
    color: "greenBright"
  }, "Main Menu")), a4_0x262d72.createElement(a4_0x4d5060, {
    id: "1",
    label: "Start Bot"
  }), a4_0x262d72.createElement(a4_0x4d5060, {
    id: "2",
    label: "Add Account"
  }), a4_0x262d72.createElement(a4_0x4d5060, {
    id: "3",
    label: "Delete Account"
  }), _0x55605b && a4_0x262d72.createElement(Box, {
    marginTop: 1
  }, a4_0x262d72.createElement(Text, {
    color: "yellowBright"
  }, a4_0x1a8fca.magenta("[") + a4_0x1a8fca.yellowBright("!") + a4_0x1a8fca.magenta("]"), " ", _0x55605b))), a4_0x262d72.createElement(Box, {
    marginTop: 1
  }, a4_0x262d72.createElement(Text, null, a4_0x1a8fca.magenta("[") + a4_0x1a8fca.white("CTRL") + a4_0x1a8fca.blackBright(" + ") + a4_0x1a8fca.white("C") + a4_0x1a8fca.magenta("]") + a4_0x1a8fca.blackBright(" or ") + a4_0x1a8fca.white("Q") + a4_0x1a8fca.blackBright(" for exit")))));
};
export default MainMenuComponent;
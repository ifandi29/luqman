import a6_0x497046 from "react";
import { Box, Text } from "ink";
import a6_0x14855a from "ink-spinner";
import a6_0x1b4fd7 from "chalk";
import a6_0x385eab from "./pageComponent.js";
import { formatDate } from "../utils/helper.js";
import a6_0x5906b3 from "../hooks/useStartBot.js";
const StartBotComponent = ({
  accounts: _0x2dcbfd,
  banner: _0x374b6a,
  validateLicenseKey: _0x1c4456,
  onChange: _0x383041
}) => {
  const {
    pageAccount: _0x4c247b,
    runtimeStatus: _0x1d777f,
    focusOn: _0x37c1be
  } = a6_0x5906b3({
    accounts: _0x2dcbfd,
    validateLicenseKey: _0x1c4456,
    onChange: _0x383041
  });
  return a6_0x497046.createElement(Box, {
    flexDirection: "column",
    width: 52
  }, a6_0x497046.createElement(Text, null), a6_0x497046.createElement(Box, {
    flexDirection: "column",
    marginTop: -1,
    marginX: -1,
    borderStyle: {
      topLeft: "",
      top: "",
      topRight: "",
      bottomLeft: "",
      bottom: "~",
      bottomRight: "",
      right: "",
      left: ""
    }
  }, a6_0x497046.createElement(Text, null, a6_0x1b4fd7.white("Berakhir"), a6_0x1b4fd7.blackBright(":"), " ", a6_0x1b4fd7.blue(formatDate(_0x1c4456.data.exp))), a6_0x497046.createElement(Text, null, a6_0x1b4fd7.white("Billing"), " ", a6_0x1b4fd7.blackBright(":"), " ", a6_0x1b4fd7.green((_0x1c4456.data.exp)))), a6_0x497046.createElement(Box, {
    flexDirection: "column",
    marginRight: 2
  }, _0x1d777f.status === "reconnecting" && a6_0x497046.createElement(Text, {
    color: "yellowBright"
  }, "Reconecting ", a6_0x497046.createElement(a6_0x14855a, null)), a6_0x497046.createElement(Box, {
    flexDirection: "column",
    display: _0x1d777f.status !== "reconnecting" && "flex" || "none"
  }, a6_0x497046.createElement(Box, {
    justifyContent: "center"
  }, a6_0x497046.createElement(Text, null, _0x37c1be, " / ", _0x4c247b.length)), _0x4c247b.map((_0x46d42c, _0x58451c) => a6_0x497046.createElement(a6_0x385eab, {
    key: _0x58451c,
    accounts: _0x46d42c,
    id: (_0x58451c + 1).toString()
  })), a6_0x497046.createElement(Box, {
    marginTop: -1
  }, a6_0x497046.createElement(Text, null, a6_0x1b4fd7.magenta("[") + a6_0x1b4fd7.white("CTRL") + a6_0x1b4fd7.blackBright(" + ") + a6_0x1b4fd7.white("C") + a6_0x1b4fd7.magenta("]") + a6_0x1b4fd7.blackBright(" or ") + a6_0x1b4fd7.white("Q") + a6_0x1b4fd7.blackBright(" for exit, ") + a6_0x1b4fd7.white("ESC") + a6_0x1b4fd7.blackBright(" for back"))))));
};
export default StartBotComponent;